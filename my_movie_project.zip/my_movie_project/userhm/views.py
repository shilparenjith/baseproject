from django.shortcuts import render

from my_movie_app.models import Movies


# Create your views here.
def allProdCat1(request):
    context={}
    context['movie_list'] = Movies.objects.all()
    return render(request,'movies.html',context)