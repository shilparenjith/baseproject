from django.urls import path
from.import views
app_name='userhm'
urlpatterns = [
    path('',views.allProdCat1,name='allProdCat1'),
    ]