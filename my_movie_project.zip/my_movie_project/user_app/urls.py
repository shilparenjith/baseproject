from django.urls import path
from.import views
app_name='user_app'
urlpatterns = [
    path('',views.add_detail,name='add_detail'),
    # path('', views.allProdCat, name='movies_by_category'),
    # path('', views.movDetail, name='movDetail'),
    ]
