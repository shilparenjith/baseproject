from django.db import models

# Create your models here.
from my_movie_app.models import Movies
# Create your models here.
class Add(models.Model):
    user_id=models.CharField(max_length=250,blank=True)
    movie_added=models.DateField(auto_now_add=True)
    post_reviews=models.CharField(max_length=250,blank=True)


    class Meta:
        db_table='Add'
        ordering=[]
    def __str__(self):
        return  '{}'.format(self.user_id)
class AddMovie(models.Model):
    movie=models.ForeignKey(Movies,on_delete=models.CASCADE)
    add=models.ForeignKey(Add,on_delete=models.CASCADE)
    quantity=models.IntegerField()
    active=models.BooleanField(default=True)
    class Meta:
        db_table='AddMovie'
    def __str__(self):
        return  '{}'.format(self.movie)
class Customer_movie(models.Model):
    customer_id=models.ForeignKey(Movies,on_delete=models.CASCADE)
    movie_id=models.ForeignKey(Add,on_delete=models.CASCADE)

    class Meta:
        db_table='Customer_movie'
    def __str__(self):
        return  '{}'.format(self.customer_id)