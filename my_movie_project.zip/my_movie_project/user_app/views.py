from django.shortcuts import render, redirect, get_object_or_404
from my_movie_app.models import Movies
from .models import Add,AddMovie
from django.core.exceptions import ObjectDoesNotExist
# Create your views here.
def _User_id(request):
    Add=request.session.session_key
    if not Add:
        Add=request.session.create()
    return Add
def add_movie(request,user_id):
    movie=Movies.objects.get(id=user_id)
    try:
        Add=AddMovie.objects.get(user_id=_User_id(request))
    except AddMovie.DoesNotExist:
        Add=AddMovie.objects.create(
            user_id=_User_id(request)
        )
        Add.save()
    try:
        add_movie=AddMovie.objects.get(movie=movie,add=Add)
        add_movie.quantity +=1
        add_movie.save()
    except AddMovie.DoesNotExist:
        add_movie=AddMovie.objects.create(
            movie=movie,
            quantity=1,
            Add=Add
        )
        add_movie.save()
    return redirect('add:add_movie')
def add_detail(request,total=0,counter=0,add_movie=None):
    try:
        add=Add.objects.get(user_id=_User_id(request))
        add_movie=AddMovie.objects.filter(add=add,active=True)
        for add_movie in add_movie:
            # total+=(add_movie.movie.price * cart_item.quantity)
            counter +=add_movie().quantity
    except ObjectDoesNotExist:
        pass
    return render(request,'add.html',dict(add_movie=add_movie,total=total,counter=counter))


def add_remove(request,userid):
    add=Add.objects.get(userid=_User_id(request))
    movie=get_object_or_404(Movies,id=_User_id)
    add_movie=AddMovie.objects.get(movie=movie,add=add)
    if add_movie.quantity > 1:
        add_movie.quantity -=1
        add_movie.save()
    else:
        add_movie.delete()
    return  redirect('user_app:add_movie')

def full_remove(request,user_id):
    add=Add.objects.get(user_id=_User_id(request))
    movie=get_object_or_404(Movies,id=user_id)
    add=AddMovie.objects.get(movie=movie,add=add)
    add.delete()
    return redirect('user_app:add_movie')