from django.shortcuts import render, get_object_or_404, redirect,HttpResponse
from .models import Category, Movies, Review
from django.core.paginator import Paginator,EmptyPage,InvalidPage

from .movieform import movie_form
from .reviewform import Reviewform


# Create your views here.
def allProdCat(request,c_slug=None):
    c_page= None
    movie_list=None
    if c_slug!=None:
        c_page=get_object_or_404(Category)
        movie_list=Movies.objects.all().filter(category=c_page)
    else:
        movie_list=Movies.objects.all()
    paginator=Paginator(movie_list,6)
    try:
        page=int(request.GET.get('page','1'))
    except:
        page=1
    try:
        movie=paginator.page(page)
    except (EmptyPage,InvalidPage):
        movie=paginator.page(paginator.num_pages)

    return render(request,'category.html',{'category':c_page,'movies':movie_list})
def movDetail(request):
    try:
        movie=Movies.objects.get(category=Category)
    except Exception as e:
        raise e
    return render(request,'movie.html',{"movie":movie})

def allProdCat1(request):
    context={}
    context['movie_list'] = Movies.objects.all()
    return render(request,'category.html',context)

def insertMovie(request):
    context={}
    frm=movie_form(request.POST or None, request.FILES or None)
    if frm.is_valid():
        frm.save()
        return redirect('/my_movie_app/insertMovie')
    context['moviefrm']=frm
    context['list']=Movies.objects.all()
    return render(request,'insertMovie.html',context)

def updateMovie(request,mid):
    context={}
    obj=get_object_or_404(Movies,id=mid)
    frm = movie_form(request.POST or None, request.FILES or None,instance=obj)
    if frm.is_valid():
        frm.save()
        return redirect('/my_movie_app/insertMovie')
    context['moviefrm']=frm

    return render(request,'editMovie.html',context)

def DeleteMovie(request,mid):
    context={}
    obj=get_object_or_404(Movies,id=mid)
    obj.delete()
    return redirect('/my_movie_app/insertMovie')

def AddReview(request,mid):
    context={}

    frm=Reviewform(request.POST or None)
    cust=request.POST.get('Customer')
    rev = request.POST.get('Review')
    if frm.is_valid():
        review=Review.objects.create(movie_id=mid,Customer=cust,Review=rev)
        return redirect('/AddReview<mid>')
    context['frm']=frm
    context['list']=Review.objects.all()
    return render(request,'addReview.html',context)