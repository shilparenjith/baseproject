from django.db import models
from django.urls import reverse
from django.core.validators import URLValidator



class Category(models.Model):

    genre=models.CharField(max_length=250,unique=True)


    class Meta:
        ordering=('genre',)
        verbose_name='category'
        verbose_name_plural='categories'

    def get_url(self):
        return reverse('movies_by_category',args=[self.genre])
    def __str__(self):
        return  '{}'.format(self.genre)
# Create your models here.
class Movies(models.Model):
    movie_title=models.CharField(max_length=250,unique=True)
    Poster = models.ImageField(upload_to='category', blank=True)
    description=models.TextField(blank=True)
    release_date=models.DateTimeField(auto_now_add=True)
    actors=models.TextField(blank=True)
    category=models.ForeignKey(Category,on_delete=models.CASCADE)
    Youtube_link=models.CharField(max_length=200,validators=[URLValidator()])

    def get_url(self):
        return  reverse('my_movie_app:movies_by_category',args=[self.category])

    class Meta:
        ordering=('movie_title',)
        verbose_name='movie'
        verbose_name_plural='movies'

    def __str__(self):
        return  '{}'.format(self.movie_title)

class Review(models.Model):
    movie_id=models.CharField(max_length=250)
    Customer = models.CharField(max_length=20,unique=True)
    Review=models.TextField(blank=True)
    Date=models.DateTimeField(auto_now_add=True)