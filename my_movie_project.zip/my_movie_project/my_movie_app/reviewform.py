from django import forms

from my_movie_app.models import Movies, Review


class Reviewform(forms.ModelForm):
    class Meta:
        model=Review
        fields=('Customer','Review')
