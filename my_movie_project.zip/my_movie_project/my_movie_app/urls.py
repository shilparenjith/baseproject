from django.urls import path
from.import views
app_name='my_movie_app'
urlpatterns = [
    path('',views.allProdCat,name='allProdCat'),
    path('allProdCat1',views.allProdCat1,name='allProdCat1'),
    path('movDetail', views.movDetail, name='movDetail'),
    path('insertMovie', views.insertMovie, name='insertMovie'),
    path('AddReview/<mid>', views.AddReview, name='AddReview'),
    path('updateMovie/<mid>', views.updateMovie, name='updateMovie'),
    path('DeleteMovie/<mid>', views.DeleteMovie, name='DeleteMovie'),

    ]

