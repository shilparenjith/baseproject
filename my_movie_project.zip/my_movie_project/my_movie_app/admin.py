from django.contrib import admin
from .models import Category,Movies

# Register your models here.
class  CategoryAdmin(admin.ModelAdmin):
    list_display = []
admin.site.register(Category,CategoryAdmin)
class  MoviesAdmin(admin.ModelAdmin):
    list_display = ['description','release_date','actors']
    list_editable =[]
    list_per_page = 20
admin.site.register(Movies,MoviesAdmin)