from django import forms

from my_movie_app.models import Movies


class movie_form(forms.ModelForm):
    class Meta:
        model=Movies
        fields=('movie_title','Poster','description','actors','category','Youtube_link')

