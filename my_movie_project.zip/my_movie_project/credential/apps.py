from django.apps import AppConfig


class CredentialConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'credential'
