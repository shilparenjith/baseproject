from django.shortcuts import render
from my_movie_app.models import Movies
from django.db.models import Q


def SearchResult(request):
    movies=None
    query=None
    if 'q' in request.GET:
        query=request.GET.get('q')
        movies=Movies.objects.all().filter(Q(movie_title__contains=query)|Q(description__contains=query))
        return render(request,'search.html',{'query':query,'movies':movies})
from django.shortcuts import render

# Create your views here.
